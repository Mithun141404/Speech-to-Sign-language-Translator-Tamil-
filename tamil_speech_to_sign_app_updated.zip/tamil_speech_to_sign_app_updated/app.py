
import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
import sounddevice as sd
from scipy.io.wavfile import write
import torch
from transformers import Wav2Vec2Processor, Wav2Vec2ForCTC
import os
import numpy as np
import torchaudio

API_TOKEN = "hf_bCyQaDloKfZVWJAgprgzKtuvHTTGZTLXK"
MODEL_ID = "Amrrs/wav2vec2-large-xlsr-53-tamil"
SIGN_IMAGE_PATH = "tamil_alphabets"
AUDIO_FILENAME = "output.wav"

ALLOWED_TAMIL_LETTERS = set("""
அ ஆ இ ஈ உ ஊ எ ஏ ஐ ஒ ஓ ஔ ஃ 
க கா கி கீ கு கூ கெ கே கை கொ கோ கௌ க்
ங ஙா ஙி ஙீ ஙு ஙூ ஙெ ஙே ஙை ஙொ ஙோ ஙௌ ங்
ச சா சி சீ சு சூ செ சே சை சொ சோ சௌ ச்
ஞ ஞா ஞி ஞீ ஞு ஞூ ஞெ ஞே ஞை ஞொ ஞோ ஞௌ ஞ்
ட டா டி டீ டு டூ டெ டே டை டொ டோ டௌ ட்
ண ணா ணி ணீ ணு ணூ ணெ ணே ணை ணொ ணோ ணௌ ண்
த தா தீ தி து தூ தெ தே தை தொ தோ தௌ த்
ந நா நி நீ நு நூ நெ நே நை நொ நோ நௌ ந்
ப பா பி பீ பு பூ பெ பே பை பொ போ பௌ ப்
ம மா மி மீ மு மூ மெ மே மை மொ மோ மௌ ம்
ய யா யி யீ யு யூ யெ யே யை யொ யோ யௌ ய்
ர ரா ரி ரீ ரு ரூ ரெ ரே ரை ரொ ரோ ரௌ ர்
ல லா லி லீ லு லூ லெ லே லை லொ லோ லௌ ல்
வ வா வி வீ வு வூ வெ வே வை வொ வோ வௌ வ்
ழ ழா ழி ழீ ழு ழூ ழெ ழே ழை ழொ ழோ ழௌ ழ்
ள ளா ளி ளீ ளு ளூ ளெ ளே ளை ளொ ளோ ளௌ ள்
ற றா றி றீ று றூ றெ றே றை றொ றோ றௌ ற்
ன னா னி னீ னு னூ னெ னே னை னொ னோ னௌ ன்
""".split())

ALLOWED_TAMIL_LETTERS.update([str(i) for i in range(10)])
ALLOWED_TAMIL_LETTERS.update(["௦", "௧", "௨", "௩", "௪", "௫", "௬", "௭", "௮", "௯"])

TAMIL_TENS = {
    "பத்து": 10, "பதினொன்று": 11, "பன்னிரண்டு": 12,
    "பதிமூன்று": 13, "பதிநான்கு": 14, "பதினைந்து": 15,
    "பதினாறு": 16, "பதினேழு": 17, "பதினெட்டு": 18, "பத்தொன்பது": 19,
    "முப்பது": 30, "நாற்பது": 40, "ஐம்பது": 50,
    "அறுபது": 60, "எழுபது": 70, "எண்பது": 80, "தொண்ணூறு": 90,
    "பத்துப்": 10, "முப்பத்து": 30, "நாற்பத்து": 40,
    "ஐம்பத்து": 50, "அறுபத்து": 60, "எழுபத்து": 70,
    "எண்பத்து": 80, "தொண்ணூற்றுப்": 90, "இருபது": 20, "தொண்ணூற்று": 90
}


TAMIL_UNITS = {
    "பூஜ்யம்": 0, "பூஜ்ஜியம்": 0, "சுழியம்": 0,
    "ஒன்று": 1, "இரண்டு": 2, "மூன்று": 3, "நான்கு": 4,
    "ஐந்து": 5, "ஆறு": 6, "ஏழு": 7, "எட்டு": 8, "ஒன்பது": 9
}

TAMIL_NUMBER_WORDS = {
    "தொண்ணொன்பது": "99", "நொறைந்தொன்பது": "99",
    "எண்பத்தொன்பது": "89", "எழுபத்தேழு": "77"
}

def tamil_number_to_digits(text):
    text = text.strip()
    words = text.split()

    if text in TAMIL_NUMBER_WORDS:
        return list(TAMIL_NUMBER_WORDS[text])

    total = 0
    for word in words:
        if word in TAMIL_TENS:
            total += TAMIL_TENS[word]
        elif word in TAMIL_UNITS:
            total += TAMIL_UNITS[word]
        elif word in TAMIL_NUMBER_WORDS:
            total += int(TAMIL_NUMBER_WORDS[word])
        elif word.isdigit():
            total += int(word)

    return list(str(total)) if total > 0 else [char for char in text if char.isdigit()]

processor = Wav2Vec2Processor.from_pretrained(MODEL_ID, token=API_TOKEN)
model = Wav2Vec2ForCTC.from_pretrained(MODEL_ID, token=API_TOKEN).to("cpu")

root = tk.Tk()
root.title("Tamil Speech to Sign")
root.geometry("1000x700")
root.configure(bg="#222")

canvas = tk.Canvas(root, bg="#222", height=400, width=980, highlightthickness=0)
canvas.pack(pady=(20, 10))

transcription_label = tk.Label(root, text="", font=("Segoe UI", 20), fg="white", bg="#222")
transcription_label.pack(pady=10)

style = ttk.Style()
style.configure("TButton", font=("Segoe UI", 14), padding=10)

def clear_all():
    transcription_label.config(text="")
    canvas.delete("all")

def record_words():
    record_and_transcribe(mode="word")

def record_numbers():
    record_and_transcribe(mode="number")

def record_and_transcribe(mode="word"):
    duration = 4
    fs = 16000
    recording = sd.rec(int(duration * fs), samplerate=fs, channels=1, dtype='int16')
    sd.wait()
    write(AUDIO_FILENAME, fs, recording)

    speech, rate = torchaudio.load(AUDIO_FILENAME)
    input_values = processor(speech.squeeze(), sampling_rate=rate, return_tensors="pt").input_values
    with torch.no_grad():
        logits = model(input_values).logits
    predicted_ids = torch.argmax(logits, dim=-1)
    transcription = processor.decode(predicted_ids[0]).strip()
    transcription_label.config(text=transcription)

    if mode == "word":
        split_letters = split_tamil(transcription)
    elif mode == "number":
        split_letters = tamil_number_to_digits(transcription)
    else:
        split_letters = []

    display_sign_images(split_letters)

def split_tamil(text):
    chunks = []
    i = 0
    while i < len(text):
        for size in (3, 2, 1):
            chunk = text[i:i+size]
            if chunk in ALLOWED_TAMIL_LETTERS:
                chunks.append(chunk)
                i += size
                break
        else:
            chunks.append(text[i])
            i += 1
    return chunks

image_refs = []
def display_sign_images(letters):
    global image_refs
    image_refs.clear()
    canvas.delete("all")
    canvas_width = 980
    canvas_height = 400
    spacing = 30
    total = len(letters)
    if total == 0:
        return

    box_width = min((canvas_width - spacing * (total + 1)) // total, 200)
    box_height = box_width

    start_x = (canvas_width - (box_width * total + spacing * (total - 1))) // 2
    y_pos = (canvas_height - box_height) // 2 - 20

    for i, letter in enumerate(letters):
        x = start_x + i * (box_width + spacing)
        canvas.create_rectangle(x, y_pos, x + box_width, y_pos + box_height, fill="#444", outline="")
        if letter in ALLOWED_TAMIL_LETTERS:
            image_path = os.path.join(SIGN_IMAGE_PATH, f"{letter}.jpg")
            if os.path.exists(image_path):
                img = Image.open(image_path).resize((box_width, box_height), Image.Resampling.LANCZOS)
                img = ImageTk.PhotoImage(img)
                canvas.create_image(x, y_pos, anchor="nw", image=img)
                image_refs.append(img)
            else:
                canvas.create_text(x + box_width / 2, y_pos + box_height / 2, text="❓", font=("Segoe UI Emoji", int(box_width / 2)))
        else:
            canvas.create_text(x + box_width / 2, y_pos + box_height / 2, text="🚫", font=("Segoe UI Emoji", int(box_width / 2)))

        canvas.create_text(x + box_width / 2, y_pos + box_height + 10, text=letter, font=("Segoe UI", 14, "bold"), fill="white")

btn_frame = tk.Frame(root, bg="#222")
btn_frame.pack(pady=20)

ttk.Button(btn_frame, text="🎤 Words to Sign", command=record_words).grid(row=0, column=0, padx=10)
ttk.Button(btn_frame, text="🔢 Numbers to Sign", command=record_numbers).grid(row=0, column=1, padx=10)
ttk.Button(btn_frame, text="🧹 Clear", command=clear_all).grid(row=0, column=2, padx=10)

root.mainloop()
